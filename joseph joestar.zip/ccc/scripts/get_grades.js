function showStudentGrades(assignmentId) {
  fetch(`get_student_grades.php?assignment_id=${assignmentId}`)
    .then((response) => response.json())
    .then((data) => {
      const modal = document.getElementById("studentGradesModal");
      document.getElementById("assignmentName").textContent =
        data.assignment_name;
      document.getElementById(
        "assignmentPoints"
      ).textContent = `Total Points: ${data.total_points} / Max Points: ${data.max_points}`;

      const tbody = document.getElementById("studentGradesList");
      tbody.innerHTML = "";

      data.students.forEach((student) => {
        const row = document.createElement("tr");
        row.innerHTML = `
                    <td>${student.student_name}</td>
                    <td>${student.score ?? "Not Graded"} / ${
          data.max_points
        }</td>
                    <td>${student.percentage ?? 0}%</td>
                    <td>${student.bonus_points}</td>
                    <td>${student.is_absent ? "Yes" : "No"}</td>
                    <td>
                        <button onclick="editStudentGrade(
                            ${assignmentId}, 
                            ${student.student_id}, 
                            '${student.student_name}', 
                            ${data.max_points},
                            ${student.score ?? 0},
                            ${student.bonus_points},
                            ${student.is_absent},
                            '${student.comments?.replace(/'/g, "\\'") ?? ""}'
                        )">Edit</button>
                    </td>
                `;
        tbody.appendChild(row);
      });

      modal.style.display = "block";
    })
    .catch((error) => console.error("Error:", error));
}

function editStudentGrade(
  assignmentId,
  studentId,
  studentName,
  maxPoints,
  currentScore,
  bonusPoints,
  isAbsent,
  comments
) {
  // Populate and show the edit grade modal
  document.getElementById("editGradeModal").style.display = "block";
  document.getElementById("editStudentName").textContent = studentName;
  document.getElementById("editAssignmentId").value = assignmentId;
  document.getElementById("editUserId").value = studentId;
  document.getElementById("editScore").value = currentScore;
  document.getElementById("editScore").max = maxPoints;
  document.getElementById("editBonus").value = bonusPoints;
  document.getElementById("editAbsent").checked = isAbsent;
  document.getElementById("editComments").value = comments;
}
