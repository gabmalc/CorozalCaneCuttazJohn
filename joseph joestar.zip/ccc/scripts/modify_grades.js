function updateCategoryView(categoryName) {
  const urlParams = new URLSearchParams(window.location.search);
  urlParams.set("category_name", categoryName);
  window.location.search = urlParams.toString();
}

function showAddAssignmentModal() {
  document.getElementById("addAssignmentModal").style.display = "block";
}

function hideAddAssignmentModal() {
  document.getElementById("addAssignmentModal").style.display = "none";
}

// Auto-save grades when changed
document.querySelectorAll(".grade-input").forEach((input) => {
  input.addEventListener("change", function () {
    this.closest("form").submit();
  });
});
