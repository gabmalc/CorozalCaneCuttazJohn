function makeEditable(element, studentId, field) {
  const currentValue = element.textContent.trim();
  const input = document.createElement("input");
  input.type = field === "email" ? "email" : "text";
  input.value = currentValue;
  input.className = "editing";

  element.innerHTML = "";
  element.appendChild(input);
  input.focus();

  function saveChange(newValue) {
    if (newValue.trim() === "") {
      alert("Field cannot be empty");
      return false;
    }

    const formData = new FormData();
    formData.append("update_student", "1");
    formData.append("student_id", studentId);
    formData.append("field", field);
    formData.append("value", newValue);

    fetch(window.location.href, {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === "success") {
          element.innerHTML = newValue;
          element.dataset.original = newValue;
        } else {
          alert(data.message || "Update failed");
          element.innerHTML = element.dataset.original;
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        element.innerHTML = element.dataset.original;
      });
  }

  input.onblur = function () {
    saveChange(this.value);
  };

  input.onkeydown = function (e) {
    if (e.key === "Enter") {
      saveChange(this.value);
    } else if (e.key === "Escape") {
      element.innerHTML = element.dataset.original;
    }
  };
}

function updateClass(selectElement, studentId) {
  const newClass = selectElement.value;
  const formData = new FormData();
  formData.append("update_class", "1");
  formData.append("student_id", studentId);
  formData.append("new_class", newClass);

  fetch(window.location.href, {
    method: "POST",
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.status !== "success") {
        alert("Failed to update class");
        location.reload();
      }
    })
    .catch((error) => {
      console.error("Error:", error);
      location.reload();
    });
}

function deleteStudent(studentId) {
  if (confirm("Are you sure you want to delete this student?")) {
    const formData = new FormData();
    formData.append("delete_student", "1");
    formData.append("student_id", studentId);

    fetch(window.location.href, {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === "success") {
          document.getElementById(`student-${studentId}`).remove();
        } else {
          alert("Failed to delete student");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        alert("Failed to delete student");
      });
  }
}

// Handle the add student form submission
document
  .getElementById("addStudentForm")
  .addEventListener("submit", function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    formData.append("add_student", "1");
    // Default password is added on the server side

    fetch(window.location.href, {
      method: "POST",
      body: formData,
    })
      .then((response) => {
        if (response.ok) {
          location.reload();
        } else {
          throw new Error("Network response was not ok");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        alert("Failed to add student");
      });
  });

// Previous makeEditable, updateClass, and deleteStudent functions remain the same...

// Modified select all functionality
function toggleAllCheckboxes() {
  const selectAllCheckbox = document.getElementById("selectAll");
  const checkboxes = document.querySelectorAll(".student-checkbox");

  checkboxes.forEach((checkbox) => {
    checkbox.checked = selectAllCheckbox.checked;
  });

  updateBatchDeleteButton();
}

function updateBatchDeleteButton() {
  const checkedBoxes = document.querySelectorAll(".student-checkbox:checked");
  const batchDeleteBtn = document.getElementById("batchDelete");
  batchDeleteBtn.disabled = checkedBoxes.length === 0;
}

function batchDeleteSelected() {
  const checkedBoxes = document.querySelectorAll(".student-checkbox:checked");
  const ids = Array.from(checkedBoxes).map((cb) => cb.value);

  if (!ids.length) return;

  if (confirm(`Are you sure you want to delete ${ids.length} student(s)?`)) {
    const formData = new FormData();
    formData.append("batch_delete", "1");
    formData.append("ids", JSON.stringify(ids));

    fetch(window.location.href, {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === "complete") {
          data.deleted.forEach((id) => {
            const row = document.getElementById(`student-${id}`);
            if (row) row.remove();
          });
          if (data.failed.length) {
            alert(`Failed to delete ${data.failed.length} student(s)`);
          }
          updateBatchDeleteButton();
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        alert("Failed to delete students");
      });
  }
}

// Handle individual checkbox changes
document.addEventListener("DOMContentLoaded", function () {
  // Initialize batch delete button state
  updateBatchDeleteButton();

  // Add change event listener to individual checkboxes
  document.querySelectorAll(".student-checkbox").forEach((checkbox) => {
    checkbox.addEventListener("change", function () {
      // Check if all checkboxes are selected
      const allCheckboxes = document.querySelectorAll(".student-checkbox");
      const allChecked = Array.from(allCheckboxes).every((cb) => cb.checked);
      document.getElementById("selectAll").checked = allChecked;

      updateBatchDeleteButton();
    });
  });
});

// Handle batch add form
document
  .getElementById("batchAddForm")
  .addEventListener("submit", function (e) {
    e.preventDefault();
    const formData = new FormData(this);
    const resultsDiv = document.getElementById("batchAddResults");
    resultsDiv.innerHTML = "Processing...";

    fetch(window.location.href, {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === "complete") {
          let html = "";
          data.results.forEach((result) => {
            html += `<div class="batch-${result.status}">${result.message}</div>`;
          });
          resultsDiv.innerHTML = html;

          // Reload after 3 seconds if any students were added successfully
          if (data.results.some((r) => r.status === "success")) {
            setTimeout(() => location.reload(), 3000);
          }
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        resultsDiv.innerHTML =
          '<div class="batch-error">Failed to process students</div>';
      });
  });

// Handle single student form
document
  .getElementById("addStudentForm")
  .addEventListener("submit", function (e) {
    e.preventDefault();
    const formData = new FormData(this);
    formData.append("add_student", "1");

    fetch(window.location.href, {
      method: "POST",
      body: formData,
    })
      .then((response) => {
        if (response.ok) {
          location.reload();
        } else {
          throw new Error("Network response was not ok");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        alert("Failed to add student");
      });
  });
