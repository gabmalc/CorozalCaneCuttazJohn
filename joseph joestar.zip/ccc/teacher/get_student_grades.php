<?php
// get_student_grades.php
session_start();
include '../connection.php';

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role_id'] != 3) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Unauthorized access']);
    exit();
}

if (!isset($_GET['assignment_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Assignment ID is required']);
    exit();
}

$assignment_id = $_GET['assignment_id'];

// Get assignment info and student grades
$query = "SELECT 
            a.assignment_name,
            a.total_points as assignment_total,
            a.max_points as assignment_max,
            u.id as student_id,
            u.name as student_name,
            g.grade_id,
            g.score,
            g.earned_bonus_points,
            g.is_absent,
            g.comments,
            g.date_submitted,
            ROUND((g.score / a.max_points * 100), 2) as percentage
          FROM assignments a
          JOIN e_course ec ON a.course_id = ec.class
          JOIN user_info u ON ec.user_id = u.id
          LEFT JOIN grades g ON a.assignment_id = g.assignment_id AND g.user_id = u.id
          WHERE a.assignment_id = ? AND u.role_id = 2
          ORDER BY u.name";

$stmt = $conn->prepare($query);
$stmt->bind_param("i", $assignment_id);
$stmt->execute();
$result = $stmt->get_result();

$assignment_data = [
    'students' => [],
    'assignment_name' => '',
    'total_points' => 0,
    'max_points' => 0
];

while ($row = $result->fetch_assoc()) {
    if (empty($assignment_data['assignment_name'])) {
        $assignment_data['assignment_name'] = $row['assignment_name'];
        $assignment_data['total_points'] = $row['assignment_total'];
        $assignment_data['max_points'] = $row['assignment_max'];
    }
    
    $assignment_data['students'][] = [
        'student_id' => $row['student_id'],
        'student_name' => $row['student_name'],
        'grade_id' => $row['grade_id'],
        'score' => $row['score'],
        'percentage' => $row['percentage'] ?? 0,
        'bonus_points' => $row['earned_bonus_points'] ?? 0,
        'is_absent' => $row['is_absent'] ?? false,
        'date_submitted' => $row['date_submitted'] ? date('Y-m-d H:i', strtotime($row['date_submitted'])) : null,
        'comments' => $row['comments'] ?? ''
    ];
}

header('Content-Type: application/json');
echo json_encode($assignment_data);
?>

<!-- Update the modal HTML in your main file -->
<div id="studentGradesModal" class="modal">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="assignmentName"></h3>
            <div id="assignmentPoints"></div>
        </div>
        <div class="student-grades-container">
            <table class="student-grades-table">
                <thead>
                    <tr>
                        <th>Student Name</th>
                        <th>Grade</th>
                        <th>Percentage</th>
                        <th>Bonus</th>
                        <th>Absent</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody id="studentGradesList">
                    <!-- Will be populated by JavaScript -->
                </tbody>
            </table>
        </div>
        <button onclick="hideStudentGradesModal()">Close</button>
    </div>
</div>

<!-- Update the JavaScript for handling the modal -->
<script src="../scripts/get_grades.js">

</script>

</body>

</html>