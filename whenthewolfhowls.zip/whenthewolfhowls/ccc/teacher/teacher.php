<?php
session_start();
include '../connection.php';

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role_id'] != 3 ) {
    header("Location: login.php");
    exit();
}

// Get teacher's information and courses
$teacher_id = $_SESSION['id'];
$teacher_name = $_SESSION['name'];

// Fetch courses taught by this teacher
$courses_query = "SELECT * FROM courses WHERE instructor = ?";
$stmt = $conn->prepare($courses_query);
$stmt->bind_param("s", $teacher_name);
$stmt->execute();
$courses_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link rel="stylesheet" href="../styles/teacher.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="styles/style2.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">
</head>
<body>
<nav class="custom-navbar navbar navbar-expand-lg nav-link" style="border-radius:0px; border-bottom: 2px solid #FFD700;">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand nav-link" href="teacher.php" style="font-family:'Schibsted Grotesk'; font-weight: bolder">CCMM Teacher</a>
            <a class="navbar-brand nav-link" href="../logout.php" style="font-family:'Schibsted Grotesk'; font-weight: bolder">Logout</a>
        </div>
        <ul class="nav navbar-nav">
        </ul>
    </div>
</nav>
    <div class="welcome-header">
        <h2 stle="">Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?>!</h2>
    </div>

    <div class="dashboard-gridS">
        <!-- Courses Card -->
        <div class="dashboard-card">
            <h3 class="card-title">Your Courses</h3>
            <div class="course-list">
                <?php if ($courses_result->num_rows > 0): ?>
                    <?php while ($course = $courses_result->fetch_assoc()): ?>
                        <div class="course-item">
                            <?php echo htmlspecialchars($course['course_name']); ?> 
                            (<?php echo htmlspecialchars($course['credits']); ?> credits)
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p>No courses assigned yet.</p>
                <?php endif; ?>
            </div>
            <a href="view-classes.php" class="action-btn view">View Classes</a>
        </div>

        <!-- Grade Management Card -->
        <div class="dashboard-card">
            <h3 class="card-title">Grade Management</h3>
            <p>Manage student grades for your courses</p>
            <a href="modify_grades.php" class="action-btn grades">Modify Grades</a>
        </div>

        <!-- Demerits Card -->
        <div class="dashboard-card">
            <h3 class="card-title">Student Conduct</h3>
            <p>Record and manage student demerits</p>
            <a href="modify-demerits.php" class="action-btn demerits">Add Demerits</a>
        </div>
    </div>
</body>
</html>