<?php
header('Content-Type: application/json');

include "connection.php";
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db_name", $db_username, $db_password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $course_id = $_GET['course_id'] ?? 0;

    // Get students enrolled in the course
    $stmt = $pdo->prepare("
      SELECT ui.id, ui.name 
      FROM user_info ui 
      JOIN e_course ec ON ui.id = ec.user_id 
      WHERE ec.class = ? AND ui.role_id = 2
      ORDER BY ui.name
  ");
    $stmt->execute([$course_id]);
    $students = $stmt->fetchAll(PDO::FETCH_ASSOC);

    echo json_encode($students);

} catch(PDOException $e) {
    echo json_encode(['error' => $e->getMessage()]);
}
?>