function makeEditable(element, teacherId, field) {
  const currentValue = element.textContent.trim();
  const input = document.createElement("input");
  input.type = field === "email" ? "email" : "text";
  input.value = currentValue;
  input.className = "editing";

  element.innerHTML = "";
  element.appendChild(input);
  input.focus();

  function saveChange(newValue) {
    if (newValue.trim() === "") {
      alert("Field cannot be empty");
      return false;
    }

    const formData = new FormData();
    formData.append("update_teacher", "1");
    formData.append("teacher_id", teacherId);
    formData.append("field", field);
    formData.append("value", newValue);

    fetch(window.location.href, {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === "success") {
          element.innerHTML = newValue;
          element.dataset.original = newValue;
          if (field === "name") {
            location.reload(); // Reload to update course assignments
          }
        } else {
          alert(data.message || "Update failed");
          element.innerHTML = element.dataset.original;
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        element.innerHTML = element.dataset.original;
      });
  }

  input.onblur = function () {
    saveChange(this.value);
  };

  input.onkeydown = function (e) {
    if (e.key === "Enter") {
      saveChange(this.value);
    } else if (e.key === "Escape") {
      element.innerHTML = element.dataset.original;
    }
  };
}

function updateCourses(teacherId) {
  const courseCheckboxes = document.querySelectorAll(
    `.course-checkbox[data-teacher-id="${teacherId}"]`
  );
  const selectedCourses = Array.from(courseCheckboxes)
    .filter((cb) => cb.checked)
    .map((cb) => cb.value);

  // Show loading state
  const courseList = document.querySelector(
    `#teacher-${teacherId} .course-list`
  );
  courseList.style.opacity = "0.5";

  const formData = new FormData();
  formData.append("update_courses", "1");
  formData.append("teacher_id", teacherId);
  formData.append("courses", JSON.stringify(selectedCourses));

  fetch(window.location.href, {
    method: "POST",
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      courseList.style.opacity = "1";
      if (data.status === "success") {
        // Add success feedback
        courseList.style.backgroundColor = "#e8f5e9";
        setTimeout(() => {
          courseList.style.backgroundColor = "";
        }, 1000);
      } else {
        alert("Error updating course assignments");
        location.reload();
      }
    })
    .catch((error) => {
      console.error("Error:", error);
      alert("Error updating course assignments");
      location.reload();
    });
}

function deleteTeacher(teacherId) {
  if (
    confirm(
      "Are you sure you want to delete this teacher? This will also remove all their course assignments."
    )
  ) {
    const teacherRow = document.getElementById(`teacher-${teacherId}`);
    teacherRow.style.opacity = "0.5";

    const formData = new FormData();
    formData.append("delete_teacher", "1");
    formData.append("teacher_id", teacherId);

    fetch(window.location.href, {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === "success") {
          teacherRow.remove();
        } else {
          alert("Failed to delete teacher");
          teacherRow.style.opacity = "1";
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        alert("Failed to delete teacher");
        teacherRow.style.opacity = "1";
      });
  }
}

// Add event listener for the add teacher form
document
  .getElementById("addTeacherForm")
  .addEventListener("submit", function (e) {
    e.preventDefault();

    const formData = new FormData(this);
    formData.append("add_teacher", "1");

    // Add visual feedback
    const submitButton = this.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.textContent = "Adding...";
    submitButton.disabled = true;

    fetch(window.location.href, {
      method: "POST",
      body: formData,
    })
      .then((response) => {
        if (response.ok) {
          location.reload();
        } else {
          throw new Error("Network response was not ok");
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        alert("Failed to add teacher");
        submitButton.textContent = originalText;
        submitButton.disabled = false;
      });
  });

// Initialize tooltips
document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll(".editable").forEach((element) => {
    element.title = "Click to edit";
  });

  // Add visual feedback for checkboxes
  document.querySelectorAll(".course-checkbox").forEach((checkbox) => {
    checkbox.addEventListener("change", function () {
      const label = this.closest("label");
      label.style.backgroundColor = "#e8f5e9";
      setTimeout(() => {
        label.style.backgroundColor = "";
      }, 1000);
    });
  });
});

function updateInstructor(select, courseId) {
  const value = select.value;
  fetch("modify-courses.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: `update_course=1&course_id=${courseId}&field=instructor&value=${encodeURIComponent(
      value
    )}`,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.status === "error") {
        alert(data.message);
        select.value = select.getAttribute("data-original");
      }
    })
    .catch((error) => {
      console.error("Error:", error);
      select.value = select.getAttribute("data-original");
    });
}
