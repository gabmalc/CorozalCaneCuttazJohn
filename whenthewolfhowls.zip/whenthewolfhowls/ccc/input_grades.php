<?php
session_start();
$host = 'localhost';
$dbname = 'dbtest';
$username = 'root';
$password = '';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Fetch courses
    $stmt = $pdo->query("SELECT * FROM courses ORDER BY course_name");
    $courses = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Fetch grade categories
    $stmt = $pdo->query("SELECT * FROM grade_categories ORDER BY category_name");
    $categories = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Handle form submission
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        // First, create the assignment
        $stmt = $pdo->prepare("INSERT INTO assignments (course_id, category_id, assignment_name, total_points, max_points, due_date) 
                            VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([
            $_POST['course_id'],
            $_POST['category_id'],
            $_POST['assignment_name'],
            $_POST['total_points'],
            $_POST['total_points'], // max_points same as total_points
            $_POST['due_date']
        ]);

        $assignment_id = $pdo->lastInsertId();

        // Then insert grades for each student
        foreach ($_POST['grades'] as $student_id => $score) {
            if ($score !== '') {
                $stmt = $pdo->prepare("INSERT INTO grades (assignment_id, user_id, total_points, score, date_submitted) 
                                   VALUES (?, ?, ?, ?, NOW())");
                $stmt->execute([
                    $assignment_id,
                    $student_id,
                    $_POST['total_points'],
                    $score
                ]);
            }
        }

        echo "<div class='success-message'>Grades successfully added!</div>";
    }
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Input Grades</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f5f5;
            padding: 20px;
        }

        .container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        .form-group {
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 5px;
            font-weight: bold;
        }

        select, input[type="text"], input[type="number"], input[type="datetime-local"] {
            width: 100%;
            padding: 8px;
            border: 1px solid #ddd;
            border-radius: 4px;
            margin-bottom: 10px;
        }

        .students-grid {
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
            gap: 15px;
            margin-top: 20px;
        }

        .student-input {
            background: #f8f9fa;
            padding: 15px;
            border-radius: 4px;
        }

        .submit-btn {
            background-color: #2c3e50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
        }

        .submit-btn:hover {
            background-color: #34495e;
        }

        .success-message {
            background-color: #d4edda;
            color: #155724;
            padding: 15px;
            margin-bottom: 20px;
            border-radius: 4px;
            text-align: center;
        }

        @media (max-width: 768px) {
            .container {
                padding: 15px;
            }

            .students-grid {
                grid-template-columns: 1fr;
            }
        }
    </style>
</head>
<body>
<div class="container">
    <h1>Input Grades</h1>
    <form method="POST">
        <div class="form-group">
            <label for="course_id">Select Course:</label>
            <select name="course_id" id="course_id" required onchange="loadStudents(this.value)">
                <option value="">Select a course</option>
                <?php foreach ($courses as $course): ?>
                    <option value="<?php echo $course['course_id']; ?>">
                        <?php echo htmlspecialchars($course['course_name']); ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="category_id">Grade Category:</label>
            <select name="category_id" id="category_id" required>
                <option value="">Select a category</option>
                <?php foreach ($categories as $category): ?>
                    <option value="<?php echo $category['category_id']; ?>">
                        <?php echo htmlspecialchars($category['category_name']); ?>
                        (<?php echo htmlspecialchars($category['weight']); ?>%)
                    </option>
                <?php endforeach; ?>
            </select>
        </div>

        <div class="form-group">
            <label for="assignment_name">Assignment Name:</label>
            <input type="text" name="assignment_name" id="assignment_name" required>
        </div>

        <div class="form-group">
            <label for="total_points">Total Points:</label>
            <input type="number" name="total_points" id="total_points" required>
        </div>

        <div class="form-group">
            <label for="due_date">Due Date:</label>
            <input type="datetime-local" name="due_date" id="due_date" required>
        </div>

        <div id="students-container" class="students-grid">
            <!-- Students will be loaded here via AJAX -->
        </div>

        <button type="submit" class="submit-btn">Submit Grades</button>
    </form>
</div>

<script>
    function loadStudents(courseId) {
        if (!courseId) return;

        fetch(`get_students.php?course_id=${courseId}`)
            .then(response => response.json())
            .then(students => {
                const container = document.getElementById('students-container');
                container.innerHTML = '';

                students.forEach(student => {
                    const div = document.createElement('div');
                    div.className = 'student-input';
                    div.innerHTML = `
                      <label for="grade_${student.id}">${student.name}:</label>
                      <input type="number"
                             name="grades[${student.id}]"
                             id="grade_${student.id}"
                             min="0"
                             step="0.1"
                             max="${document.getElementById('total_points').value}">
                  `;
                    container.appendChild(div);
                });
            })
            .catch(error => console.error('Error:', error));
    }

    // Update max grades when total points change
    document.getElementById('total_points').addEventListener('change', function() {
        const inputs = document.querySelectorAll('[id^="grade_"]');
        inputs.forEach(input => {
            input.max = this.value;
        });
    });
</script>
</body>
</html>