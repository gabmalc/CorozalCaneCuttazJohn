<?php
session_start();
include '../connection.php';

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role_id'] != 3 ) {
    header("Location: login.php");
    exit();
}

// Get teacher's information and courses
$teacher_id = $_SESSION['id'];
$teacher_name = $_SESSION['name'];

// Fetch courses taught by this teacher
$courses_query = "SELECT * FROM courses WHERE instructor = ?";
$stmt = $conn->prepare($courses_query);
$stmt->bind_param("s", $teacher_name);
$stmt->execute();
$courses_result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Teacher Dashboard</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../styles/teacher.css">
</head>
<body>
    <div class="welcome-header">
        <h2>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?>!</h2>
        <form action="../login.php">
            <input type="submit" value="Logout" class="logout-btn">
        </form>
    </div>

    <div class="dashboard-gridS">
        <!-- Courses Card -->
        <div class="dashboard-card">
            <h3 class="card-title">Your Courses</h3>
            <div class="course-list">
                <?php if ($courses_result->num_rows > 0): ?>
                    <?php while ($course = $courses_result->fetch_assoc()): ?>
                        <div class="course-item">
                            <?php echo htmlspecialchars($course['course_name']); ?> 
                            (<?php echo htmlspecialchars($course['credits']); ?> credits)
                        </div>
                    <?php endwhile; ?>
                <?php else: ?>
                    <p>No courses assigned yet.</p>
                <?php endif; ?>
            </div>
            <a href="view-classes.php" class="action-btn view">View Classes</a>
        </div>

        <!-- Grade Management Card -->
        <div class="dashboard-card">
            <h3 class="card-title">Grade Management</h3>
            <p>Manage student grades for your courses</p>
            <a href="modify_grades.php" class="action-btn grades">Modify Grades</a>
        </div>

        <!-- Demerits Card -->
        <div class="dashboard-card">
            <h3 class="card-title">Student Conduct</h3>
            <p>Record and manage student demerits</p>
            <a href="add_demerits.php" class="action-btn demerits">Add Demerits</a>
        </div>
    </div>
</body>
</html>