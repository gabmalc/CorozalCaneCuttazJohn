<?php
session_start();
include '../connection.php';

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role_id'] != 3) {
    header("Location: ../login.php");
    exit();
}

$teacher_name = $_SESSION['name'];
$message = '';
$error = '';

// Get teacher's courses
$courses_query = "SELECT * FROM courses WHERE instructor = ?";
$stmt = $conn->prepare($courses_query);
$stmt->bind_param("s", $teacher_name);
$stmt->execute();
$courses_result = $stmt->get_result();

// Get grade categories
$categories = $conn->query("SELECT * FROM grade_categories");

// Add new assignment
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_assignment'])) {
    $course_id = $_POST['course_id'];
    $category_id = $_POST['category_id'];
    $assignment_name = $_POST['assignment_name'];
    $total_points = $_POST['total_points'];
    $max_points = $_POST['max_points'];
    $due_date = $_POST['due_date'];

    $stmt = $conn->prepare("INSERT INTO assignments (course_id, category_id, assignment_name, total_points, max_points, due_date) 
                           VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("iisiis", $course_id, $category_id, $assignment_name, $total_points, $max_points, $due_date);
    
    if ($stmt->execute()) {
        $message = "Assignment added successfully";
    } else {
        $error = "Error adding assignment";
    }
}

// Add or update student grade
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_grade'])) {
    $assignment_id = $_POST['assignment_id'];
    $user_id = $_POST['user_id'];
    $score = $_POST['score'];
    
    // Get assignment's total points
    $stmt = $conn->prepare("SELECT total_points FROM assignments WHERE assignment_id = ?");
    $stmt->bind_param("i", $assignment_id);
    $stmt->execute();
    $total_points = $stmt->get_result()->fetch_assoc()['total_points'];
    
    // Check if grade exists
    $check_stmt = $conn->prepare("SELECT grade_id, score FROM grades WHERE assignment_id = ? AND user_id = ?");
    $check_stmt->bind_param("ii", $assignment_id, $user_id);
    $check_stmt->execute();
    $existing_grade = $check_stmt->get_result()->fetch_assoc();

    if ($existing_grade) {
        // Insert into grade history
        $stmt = $conn->prepare("INSERT INTO grade_history (grade_id, old_score, new_score, changed_date) VALUES (?, ?, ?, NOW())");
        $stmt->bind_param("idd", $existing_grade['grade_id'], $existing_grade['score'], $score);
        $stmt->execute();

        // Update grade
        $stmt = $conn->prepare("UPDATE grades SET score = ? WHERE assignment_id = ? AND user_id = ?");
        $stmt->bind_param("dii", $score, $assignment_id, $user_id);
        $stmt->execute();
    } else {
        // Insert new grade
        $stmt = $conn->prepare("INSERT INTO grades (assignment_id, user_id, score, total_points) VALUES (?, ?, ?, ?)");
        $stmt->bind_param("iidi", $assignment_id, $user_id, $score, $total_points);
        $stmt->execute();
    }
}

// Delete assignment
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['delete_assignment'])) {
    $assignment_id = $_POST['assignment_id'];
    
    // Begin transaction
    $conn->begin_transaction();
    
    try {
        // Delete related grade history records
        $stmt = $conn->prepare("DELETE FROM grade_history WHERE grade_id IN 
                              (SELECT grade_id FROM grades WHERE assignment_id = ?)");
        $stmt->bind_param("i", $assignment_id);
        $stmt->execute();
        
        // Delete grades
        $stmt = $conn->prepare("DELETE FROM grades WHERE assignment_id = ?");
        $stmt->bind_param("i", $assignment_id);
        $stmt->execute();
        
        // Delete assignment
        $stmt = $conn->prepare("DELETE FROM assignments WHERE assignment_id = ?");
        $stmt->bind_param("i", $assignment_id);
        $stmt->execute();
        
        $conn->commit();
        $message = "Assignment deleted successfully";
    } catch (Exception $e) {
        $conn->rollback();
        $error = "Error deleting assignment: " . $e->getMessage();
    }
}

// Calculate student grade with category averages
// Update the calculateGrade function
function calculateGrade($student_id, $course_id, $conn) {
    $query = "SELECT a.assignment_id, gc.weight, gc.category_name, g.score, a.max_points 
              FROM assignments a 
              JOIN grade_categories gc ON a.category_id = gc.category_id 
              LEFT JOIN grades g ON a.assignment_id = g.assignment_id AND g.user_id = ? 
              WHERE a.course_id = ?";
    
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $student_id, $course_id);
    $stmt->execute();
    $results = $stmt->get_result();
    
    $categories = [];
    $hasAnyGrades = false;
    $totalWeightWithGrades = 0;
    
    while ($row = $results->fetch_assoc()) {
        if (!isset($categories[$row['category_name']])) {
            $categories[$row['category_name']] = [
                'weight' => $row['weight'],
                'scores' => [],
                'hasGrades' => false
            ];
        }
        
        if ($row['score'] !== null) {
            $hasAnyGrades = true;
            $categories[$row['category_name']]['hasGrades'] = true;
            $categories[$row['category_name']]['scores'][] = ($row['score'] / $row['max_points']) * 100;
        }
    }
    
    // If no grades at all, return 0
    if (!$hasAnyGrades) {
        return 0;
    }
    
    $finalGrade = 0;
    
    // Only calculate averages for categories that have grades
    foreach ($categories as $category => $data) {
        if (!empty($data['scores'])) {
            $categoryAvg = array_sum($data['scores']) / count($data['scores']);
            $weight = $data['weight'];
            $finalGrade += ($categoryAvg * ($weight / 100));
            $totalWeightWithGrades += $weight;
        }
    }
    
    // Adjust the final grade based on the total weight of categories that have grades
    if ($totalWeightWithGrades > 0) {
        $finalGrade = ($finalGrade / $totalWeightWithGrades) * 100;
    }
    
    return round($finalGrade, 2);
}

// Get assignments and grades if course is selected
if (isset($_GET['course_id'])) {
    $selected_course_id = $_GET['course_id'];
    
    $assignments_query = "SELECT a.*, gc.category_name, gc.weight 
                         FROM assignments a 
                         JOIN grade_categories gc ON a.category_id = gc.category_id 
                         WHERE a.course_id = ? 
                         ORDER BY a.due_date";
    $stmt = $conn->prepare($assignments_query);
    $stmt->bind_param("i", $selected_course_id);
    $stmt->execute();
    $assignments = $stmt->get_result();

    $students_query = "SELECT DISTINCT u.* 
                      FROM user_info u 
                      JOIN e_course e ON u.id = e.user_id 
                      WHERE e.class = ? AND u.role_id = 2 
                      ORDER BY u.name";
    $stmt = $conn->prepare($students_query);
    $stmt->bind_param("i", $selected_course_id);
    $stmt->execute();
    $students = $stmt->get_result();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grade Management</title>
    <link rel="stylesheet" href="../styles/teacher.css">
    <style>
        .grade-input { width: 60px; }
        .delete-btn { 
            background: #ff4444;
            color: white;
            border: none;
            padding: 5px 10px;
            border-radius: 3px;
            cursor: pointer;
        }
        .grade-history {
            font-size: 0.8em;
            color: #666;
            margin-top: 5px;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2>Grade Management</h2>
        <a href="teacher.php" class="back-btn">Back to Dashboard</a>

        <?php if ($message): ?>
            <div class="success"><?php echo $message; ?></div>
        <?php endif; ?>
        <?php if ($error): ?>
            <div class="error"><?php echo $error; ?></div>
        <?php endif; ?>

        <!-- Course Selection -->
        <form method="get" class="course-select">
            <select name="course_id" onchange="this.form.submit()">
                <option value="">Select Course</option>
                <?php while ($course = $courses_result->fetch_assoc()): ?>
                    <option value="<?php echo $course['course_id']; ?>"
                            <?php echo (isset($_GET['course_id']) && $_GET['course_id'] == $course['course_id']) ? 'selected' : ''; ?>>
                        <?php echo htmlspecialchars($course['course_name']); ?>
                    </option>
                <?php endwhile; ?>
            </select>
        </form>

        <?php if (isset($_GET['course_id'])): ?>
            <!-- Add Assignment Form -->
            <form method="post" class="grade-form">
                <h3>Add New Assignment</h3>
                <input type="hidden" name="course_id" value="<?php echo $_GET['course_id']; ?>">
                <input type="text" name="assignment_name" placeholder="Assignment Name" required>
                
                <select name="category_id" required>
                    <option value="">Select Category</option>
                    <?php while ($category = $categories->fetch_assoc()): ?>
                        <option value="<?php echo $category['category_id']; ?>">
                            <?php echo htmlspecialchars($category['category_name']); ?> (<?php echo $category['weight']; ?>%)
                        </option>
                    <?php endwhile; ?>
                </select>
                
                <input type="number" name="total_points" placeholder="Total Points" required>
                <input type="number" name="max_points" placeholder="Max Points" required>
                <input type="datetime-local" name="due_date" required>
                <button type="submit" name="add_assignment">Add Assignment</button>
            </form>

            <!-- Display Grades -->
            <?php if ($assignments && $assignments->num_rows > 0): ?>
                <table class="grade-table">
                    <tr>
                        <th>Student</th>
                        <?php 
                        $assignments->data_seek(0);
                        while ($assignment = $assignments->fetch_assoc()): ?>
                            <th>
                                <?php echo htmlspecialchars($assignment['assignment_name']); ?>
                                (<?php echo $assignment['category_name']; ?> - <?php echo $assignment['weight']; ?>%)
                                <form method="post" onsubmit="return confirm('Are you sure you want to delete this assignment?');">
                                    <input type="hidden" name="assignment_id" value="<?php echo $assignment['assignment_id']; ?>">
                                    <button type="submit" name="delete_assignment" class="delete-btn">Delete</button>
                                </form>
                            </th>
                        <?php endwhile; ?>
                        <th>Final Grade</th>
                    </tr>
                    <?php 
                    while ($student = $students->fetch_assoc()): 
                        $final_grade = calculateGrade($student['id'], $_GET['course_id'], $conn);
                    ?>
                        <tr>
                            <td><?php echo htmlspecialchars($student['name']); ?></td>
                            <?php 
                            $assignments->data_seek(0);
                            while ($assignment = $assignments->fetch_assoc()): 
                                // Get student's grade and history
                                $grade_query = "SELECT g.*, 
                                              (SELECT GROUP_CONCAT(CONCAT(old_score, ' → ', new_score, ' (', DATE_FORMAT(changed_date, '%Y-%m-%d %H:%i'), ')') SEPARATOR ', ') 
                                               FROM grade_history gh 
                                               WHERE gh.grade_id = g.grade_id) as history 
                                              FROM grades g 
                                              WHERE g.assignment_id = ? AND g.user_id = ?";
                                $stmt = $conn->prepare($grade_query);
                                $stmt->bind_param("ii", $assignment['assignment_id'], $student['id']);
                                $stmt->execute();
                                $grade_result = $stmt->get_result();
                                $grade = $grade_result->fetch_assoc();
                            ?>
                                <td>
                                    <form method="post">
                                        <input type="hidden" name="assignment_id" value="<?php echo $assignment['assignment_id']; ?>">
                                        <input type="hidden" name="user_id" value="<?php echo $student['id']; ?>">
                                        <input type="number" step="0.1" name="score" value="<?php echo $grade ? $grade['score'] : ''; ?>" 
                                               class="grade-input" min="0" max="<?php echo $assignment['max_points']; ?>">
                                        <button type="submit" name="update_grade">Update</button>
                                        <?php if ($grade && $grade['history']): ?>
                                            <div class="grade-history">History: <?php echo $grade['history']; ?></div>
                                        <?php endif; ?>
                                    </form>
                                </td>
                            <?php endwhile; ?>
                            <td><?php echo $final_grade; ?>%</td>
                        </tr>
                    <?php endwhile; ?>
                </table>
            <?php else: ?>
                <p>No assignments yet.</p>
            <?php endif; ?>
        <?php endif; ?>
    </div>
</body>
</html>