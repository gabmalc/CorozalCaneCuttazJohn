<?php
session_start();
include '../connection.php';

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role_id'] != 1) {
    header("Location: ../login.php");
    exit();
}

// Handle role updates
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_role'])) {
    $user_id = $_POST['user_id'];
    $new_role = $_POST['role_id'];
    
    $stmt = $conn->prepare("UPDATE user_info SET role_id = ? WHERE id = ?");
    $stmt->bind_param("ii", $new_role, $user_id);
    
    if ($stmt->execute()) {
        $message = "User role updated successfully";
    } else {
        $error = "Error updating user role";
    }
}

// Fetch all users with their roles
$users_query = "SELECT u.*, r.role_type, e.class_name 
                FROM user_info u 
                LEFT JOIN roles r ON u.role_id = r.role_id 
                LEFT JOIN enrollment e ON u.enrollment_id = e.enrollment_id 
                ORDER BY u.role_id, u.name";
$users_result = $conn->query($users_query);

// Fetch all roles
$roles_query = "SELECT * FROM roles ORDER BY role_id";
$roles_result = $conn->query($roles_query);
$roles = [];
while ($role = $roles_result->fetch_assoc()) {
    $roles[] = $role;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Modify Users</title>
    <style>
        * {
            font-family: 'Poppins', sans-serif;
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        .container {
            max-width: 1200px;
            margin: 20px auto;
            padding: 20px;
        }

        .header {
            display: flex;
            justify-content: space-between;
            align-items: center;
            margin-bottom: 20px;
        }

        .back-btn {
            background: #4CAF50;
            color: white;
            padding: 10px 20px;
            text-decoration: none;
            border-radius: 4px;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background: white;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }

        th, td {
            padding: 12px;
            text-align: left;
            border-bottom: 1px solid #ddd;
        }

        th {
            background: #f8f9fa;
            font-weight: 600;
        }

        tr:hover {
            background: #f5f5f5;
        }

        select, button {
            padding: 6px 12px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        button {
            background: #2196F3;
            color: white;
            border: none;
            cursor: pointer;
        }

        button:hover {
            background: #1976D2;
        }

        .message {
            padding: 10px;
            margin: 10px 0;
            border-radius: 4px;
        }

        .success { background: #dff0d8; color: #3c763d; }
        .error { background: #f2dede; color: #a94442; }

        .role-badge {
            padding: 4px 8px;
            border-radius: 4px;
            font-size: 0.9em;
            font-weight: 500;
        }

        .role-1 { background: #ff9800; color: white; } /* Admin */
        .role-2 { background: #4CAF50; color: white; } /* Student */
        .role-3 { background: #2196F3; color: white; } /* Teacher */
        .role-4 { background: #9C27B0; color: white; } /* Parent */
        .role-5 { background: #F44336; color: white; } /* CAO Admin */
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Modify Users</h1>
            <a href="admin.php" class="back-btn">Back to Dashboard</a>
        </div>

        <?php if (isset($message)): ?>
            <div class="message success"><?php echo $message; ?></div>
        <?php endif; ?>
        
        <?php if (isset($error)): ?>
            <div class="message error"><?php echo $error; ?></div>
        <?php endif; ?>

        <table>
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Username</th>
                    <th>Class</th>
                    <th>Current Role</th>
                    <th>Change Role</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($user = $users_result->fetch_assoc()): ?>
                    <tr>
                        <td><?php echo htmlspecialchars($user['name']); ?></td>
                        <td><?php echo htmlspecialchars($user['email']); ?></td>
                        <td><?php echo htmlspecialchars($user['username']); ?></td>
                        <td><?php echo $user['class_name'] ? htmlspecialchars($user['class_name']) : 'N/A'; ?></td>
                        <td>
                            <span class="role-badge role-<?php echo $user['role_id']; ?>">
                                <?php echo htmlspecialchars($user['role_type']); ?>
                            </span>
                        </td>
                        <td>
                            <form method="POST" style="display: inline;">
                                <select name="role_id">
                                    <?php foreach ($roles as $role): ?>
                                        <option value="<?php echo $role['role_id']; ?>" 
                                                <?php echo ($user['role_id'] == $role['role_id']) ? 'selected' : ''; ?>>
                                            <?php echo htmlspecialchars($role['role_type']); ?>
                                        </option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="hidden" name="user_id" value="<?php echo $user['id']; ?>">
                                <button type="submit" name="update_role">Update</button>
                            </form>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>
</body>
</html>