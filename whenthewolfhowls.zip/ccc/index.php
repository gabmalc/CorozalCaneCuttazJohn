<?php 
session_start();
 
 $_SESSION['role_id'] = $role_id;

 // Redirect based on role_id
 switch ($role_id) {
     case 1:
         header("Location: admin/admin.php");
         break;
     case 2:
         header("Location: student/home-display.php");
         break;
     case 3:
         header("Location: teacher/teacher.php");
         break;
     case 4:
         header("Location: parent/parent.php");
         break;
     default:
         header("Location: login.php"); // Redirect to login if role is invalid
 }

?>