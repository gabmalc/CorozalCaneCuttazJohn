<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Student Grades</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        }

        body {
            background-color: #f5f5f5;
            padding: 20px;
        }

        .grades-container {
            max-width: 1200px;
            margin: 0 auto;
            background: white;
            border-radius: 8px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            overflow: hidden;
        }

        .header {
            background: #2c3e50;
            color: white;
            padding: 20px;
        }

        .grades-table {
            width: 100%;
            border-collapse: collapse;
        }

        .grades-table th {
            background: #34495e;
            color: white;
            padding: 12px;
            text-align: left;
        }

        .grades-table td {
            padding: 12px;
            border-bottom: 1px solid #eee;
        }

        .grades-table tr:hover {
            background-color: #f8f9fa;
        }

        .grade-score {
            font-weight: bold;
            color: #2ecc71;
        }

        .category-badge {
            background: #3498db;
            color: white;
            padding: 4px 8px;
            border-radius: 12px;
            font-size: 0.85em;
        }

        @media screen and (max-width: 768px) {
            .grades-table {
                display: block;
                overflow-x: auto;
            }

            .grades-table thead {
                display: none;
            }

            .grades-table tr {
                display: block;
                margin-bottom: 15px;
                border: 1px solid #ddd;
                border-radius: 4px;
            }

            .grades-table td {
                display: block;
                text-align: right;
                padding: 12px;
                position: relative;
                padding-left: 50%;
            }

            .grades-table td:before {
                content: attr(data-label);
                position: absolute;
                left: 12px;
                width: 45%;
                text-align: left;
                font-weight: bold;
            }
        }
    </style>
</head>
<body>
<?php
session_start();
include "connection.php";
try {
    $pdo = new PDO("mysql:host=$host;dbname=$db_name", $db_username, $db_password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // assuming user is logged in and $_SESSION['user_id'] is set
    $user_id = $_SESSION['id'] ?? null;

    if ($user_id) {
        $query = "
                SELECT 
                    g.grade_id,
                    g.score,
                    g.total_points,
                    g.date_submitted,
                    a.assignment_name,
                    c.course_name,
                    gc.category_name,
                    gc.weight
                FROM grades g
                JOIN assignments a ON g.assignment_id = a.assignment_id
                JOIN courses c ON a.course_id = c.course_id
                JOIN grade_categories gc ON a.category_id = gc.category_id
                WHERE g.user_id = ?
                ORDER BY g.date_submitted DESC
            ";

        $stmt = $pdo->prepare($query);
        $stmt->execute([$user_id]);
        $grades = $stmt->fetchAll(PDO::FETCH_ASSOC);
        ?>
        <div class="grades-container">
            <div class="header">
                <h2>My Grades</h2>
            </div>
            <table class="grades-table">
                <thead>
                <tr>
                    <th>Course</th>
                    <th>Assignment</th>
                    <th>Category</th>
                    <th>Score</th>
                    <th>Date Submitted</th>
                </tr>
                </thead>
                <tbody>
                <?php foreach ($grades as $grade): ?>
                    <tr>
                        <td data-label="Course"><?php echo htmlspecialchars($grade['course_name']); ?></td>
                        <td data-label="Assignment"><?php echo htmlspecialchars($grade['assignment_name']); ?></td>
                        <td data-label="Category">
                                    <span class="category-badge">
                                        <?php echo htmlspecialchars($grade['category_name']); ?>
                                        (<?php echo htmlspecialchars($grade['weight']); ?>%)
                                    </span>
                        </td>
                        <td data-label="Score" class="grade-score">
                            <?php echo htmlspecialchars($grade['score']); ?>/<?php echo htmlspecialchars($grade['total_points']); ?>
                        </td>
                        <td data-label="Date Submitted">
                            <?php echo date('M d, Y', strtotime($grade['date_submitted'])); ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>
        </div>
        <?php
    } else {
        echo '<p>Please log in to view your grades.</p>';
    }
} catch(PDOException $e) {
    echo "Connection failed: " . $e->getMessage();
}
?>
</body>
</html>