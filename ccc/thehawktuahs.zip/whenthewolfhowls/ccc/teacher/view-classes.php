<?php
session_start();
include '../connection.php';

if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true || $_SESSION['role_id'] != 3) {
   header("Location: ../login.php");
   exit();
}

$teacher_name = $_SESSION['name'];

// Get all courses taught by this teacher
$courses_query = "SELECT * FROM courses WHERE instructor = ?";
$stmt = $conn->prepare($courses_query);
$stmt->bind_param("s", $teacher_name);
$stmt->execute();
$courses_result = $stmt->get_result();

// Get students for a specific course if course_id is provided
$selected_course = null;
$students_result = null;
if (isset($_GET['course_id'])) {
   $course_query = "SELECT * FROM courses WHERE course_id = ? AND instructor = ?";
   $stmt = $conn->prepare($course_query);
   $stmt->bind_param("is", $_GET['course_id'], $teacher_name);
   $stmt->execute();
   $selected_course = $stmt->get_result()->fetch_assoc();

   if ($selected_course) {
       // Get enrolled students using e_course table
       $students_query = "SELECT u.*, e.class_name, e.enrollment_id 
                         FROM user_info u 
                         JOIN enrollment e ON u.enrollment_id = e.enrollment_id 
                         JOIN e_course ec ON u.id = ec.user_id
                         WHERE ec.class = ? AND u.role_id = 2 
                         ORDER BY u.name";
       $stmt = $conn->prepare($students_query);
       $stmt->bind_param("i", $_GET['course_id']);
       $stmt->execute();
       $students_result = $stmt->get_result();
   }
}

// Function to get student average
function getStudentAverage($student_id, $class_id, $conn) {
   $stmt = $conn->prepare("
       SELECT AVG(score) as average 
       FROM grades 
       WHERE user_id = ? AND assignment_id IN (
           SELECT assignment_id FROM assignments WHERE course_id = ?
       )
   ");
   $stmt->bind_param("ii", $student_id, $class_id);
   $stmt->execute();
   $result = $stmt->get_result()->fetch_assoc();
   return $result['average'] ? round($result['average'], 2) : 'N/A';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>View Classes</title>
   <link rel="preconnect" href="https://fonts.googleapis.com">
   <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
   <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@100;200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">
   <link rel="stylesheet" href="../styles/view-classes.css">
    <link rel="stylesheet" href="../styles/admin.css" href="../styles/navbar-layout.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.7.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="styles/style2.css">
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Schibsted+Grotesk:ital,wght@0,400..900;1,400..900&display=swap" rel="stylesheet">
   <style>
       .average {
           font-weight: bold;
           color: #161a2d;
       }
       .failing {
           color: #f44336;
       }
   </style>
</head>
<body>
<nav class="custom-navbar navbar navbar-expand-lg nav-link" style="border-radius:0px; border-bottom: 2px solid #FFD700;">
    <div class="container-fluid">
        <div class="navbar-header">
            <a class="navbar-brand nav-link" href="teacher.php" style="font-family:'Schibsted Grotesk'; font-weight: bolder">CCMM Teacher</a>
            <a class="navbar-brand nav-link" href="../logout.php" style="font-family:'Schibsted Grotesk'; font-weight: bolder">Logout</a>
        </div>
        <ul class="nav navbar-nav">
        </ul>
    </div>
</nav>
   <div class="container">
       <div class="header">
           <h2>View Classes</h2>
           <a href="teacher.php" class="back-btn">Back to Dashboard</a>
       </div>

       <form method="get" class="course-info">
           <select name="course_id" class="course-select" onchange="this.form.submit()">
               <option value="">Select a Course</option>
               <?php while ($course = $courses_result->fetch_assoc()): ?>
                   <option value="<?php echo $course['course_id']; ?>" 
                           <?php echo (isset($_GET['course_id']) && $_GET['course_id'] == $course['course_id']) ? 'selected' : ''; ?>>
                       <?php echo htmlspecialchars($course['course_name']); ?>
                   </option>
               <?php endwhile; ?>
           </select>
       </form>

       <?php if ($selected_course): ?>
           <div class="course-info">
               <h3><?php echo htmlspecialchars($selected_course['course_name']); ?></h3>
               <p>Credits: <?php echo htmlspecialchars($selected_course['credits']); ?></p>
           </div>

           <?php if ($students_result && $students_result->num_rows > 0): ?>
               <table class="students-table">
                   <thead>
                       <tr>
                           <th>Student Name</th>
                           <th>Email</th>
                           <th>Class</th>
                           <th>Average</th>
                       </tr>
                   </thead>
                   <tbody>
                       <?php while ($student = $students_result->fetch_assoc()): 
                           $average = getStudentAverage($student['id'], $_GET['course_id'], $conn);
                       ?>
                           <tr>
                               <td><?php echo htmlspecialchars($student['name']); ?></td>
                               <td><?php echo htmlspecialchars($student['email']); ?></td>
                               <td><?php echo htmlspecialchars($student['class_name']); ?></td>
                               <td class="average <?php echo ($average != 'N/A' && $average < 60) ? 'failing' : ''; ?>">
                                   <?php echo $average; ?>
                               </td>
                           </tr>
                       <?php endwhile; ?>
                   </tbody>
               </table>
           <?php else: ?>
               <div class="no-students">
                   <p>No students enrolled in this course.</p>
               </div>
           <?php endif; ?>
       <?php endif; ?>
   </div>
</body>
</html>