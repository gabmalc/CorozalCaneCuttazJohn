function makeEditable(element, courseId, field, type = "text") {
  const currentValue = element.textContent.trim();
  const input = document.createElement("input");
  input.type = type;
  input.value = currentValue;
  input.className = "editing";

  if (type === "number") {
    input.min = "1";
    input.max = "10";
  }

  element.innerHTML = "";
  element.appendChild(input);
  input.focus();

  function saveChange(newValue) {
    if (newValue.trim() === "") {
      alert("Field cannot be empty");
      return false;
    }

    if (type === "number" && (newValue < 1 || newValue > 10)) {
      alert("Credits must be between 1 and 10");
      return false;
    }

    const formData = new FormData();
    formData.append("update_course", "1");
    formData.append("course_id", courseId);
    formData.append("field", field);
    formData.append("value", newValue);

    fetch(window.location.href, {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === "success") {
          element.innerHTML = newValue;
          element.dataset.original = newValue;
          // Add visual feedback
          element.style.backgroundColor = "#e8f5e9";
          setTimeout(() => {
            element.style.backgroundColor = "";
          }, 1000);
        } else {
          alert(data.message || "Update failed");
          element.innerHTML = element.dataset.original;
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        element.innerHTML = element.dataset.original;
      });
  }

  input.onblur = function () {
    if (this.value !== currentValue) {
      saveChange(this.value);
    } else {
      element.innerHTML = element.dataset.original;
    }
  };

  input.onkeydown = function (e) {
    if (e.key === "Enter") {
      if (this.value !== currentValue) {
        saveChange(this.value);
      } else {
        element.innerHTML = element.dataset.original;
      }
    } else if (e.key === "Escape") {
      element.innerHTML = element.dataset.original;
    }
  };
}

function deleteCourse(courseId) {
  if (!confirm("Are you sure you want to delete this course?")) {
    return;
  }

  const row = document.getElementById(`course-${courseId}`);
  row.style.opacity = "0.5";

  const formData = new FormData();
  formData.append("delete_course", "1");
  formData.append("course_id", courseId);

  fetch(window.location.href, {
    method: "POST",
    body: formData,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.status === "success") {
        row.remove();
      } else {
        alert(data.message || "Delete failed");
        row.style.opacity = "1";
      }
    })
    .catch((error) => {
      console.error("Error:", error);
      alert("Failed to delete course");
      row.style.opacity = "1";
    });
}

// Handle the add course form
document
  .getElementById("addCourseForm")
  .addEventListener("submit", function (e) {
    e.preventDefault();

    const courseName = this.querySelector(
      'input[name="course_name"]'
    ).value.trim();
    const credits = this.querySelector('input[name="credits"]').value;

    if (!courseName || !credits) {
      alert("Please fill in all fields");
      return;
    }

    if (credits < 1 || credits > 10) {
      alert("Credits must be between 1 and 10");
      return;
    }

    const formData = new FormData(this);
    formData.append("add_course", "1");

    const submitButton = this.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.textContent = "Adding...";
    submitButton.disabled = true;

    fetch(window.location.href, {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === "success") {
          location.reload();
        } else {
          alert(data.message || "Failed to add course");
          submitButton.textContent = originalText;
          submitButton.disabled = false;
        }
      })
      .catch((error) => {
        console.error("Error:", error);
        alert("Failed to add course");
        submitButton.textContent = originalText;
        submitButton.disabled = false;
      });
  });

// Initialize tooltips
document.addEventListener("DOMContentLoaded", function () {
  document.querySelectorAll(".editable").forEach((element) => {
    element.title = "Click to edit";
  });
});

function updateInstructor(select, courseId) {
  const value = select.value;
  fetch("modify-courses.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: `update_course=1&course_id=${courseId}&field=instructor&value=${encodeURIComponent(
      value
    )}`,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.status === "error") {
        alert(data.message);
        select.value = select.getAttribute("data-original");
      }
    })
    .catch((error) => {
      console.error("Error:", error);
      select.value = select.getAttribute("data-original");
    });
}

function updateCourse(courseId, field, value) {
  fetch("modify-courses.php", {
    method: "POST",
    headers: {
      "Content-Type": "application/x-www-form-urlencoded",
    },
    body: `update_course=1&course_id=${courseId}&field=${field}&value=${encodeURIComponent(
      value
    )}`,
  })
    .then((response) => response.json())
    .then((data) => {
      if (data.status === "error") {
        alert(data.message);
        location.reload();
      }
    })
    .catch((error) => {
      console.error("Error:", error);
      location.reload();
    });
}

document
  .getElementById("addCourseForm")
  .addEventListener("submit", function (e) {
    e.preventDefault();
    const formData = new FormData(this);
    formData.append("add_course", "1");

    fetch("modify-courses.php", {
      method: "POST",
      body: formData,
    })
      .then((response) => response.json())
      .then((data) => {
        if (data.status === "success") {
          location.reload();
        } else {
          alert(data.message);
        }
      });
  });
