<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header("Location: ../login.php");
    exit();
}

if($_SESSION["role_id"] != 1){
    header("Location: ../login.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin</title>
    <link rel="stylesheet" href="../styles/admin.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,100;0,200;0,300;0,400;0,500;0,600;0,700;0,800;0,900&display=swap" rel="stylesheet">


</head>
<body>
<h1>Welcome, <?php echo htmlspecialchars($_SESSION['name']); ?></h1>
<hr>
    <div class="grid-container">
    <form action="modify-students.php">
         <input type="submit" value="Modify Students" />
    </form> 
    <form action="modify-class.php">
         <input type="submit" value="Modify Class" />
    </form> 
    <form action="modify-users.php">
         <input type="submit" value="Modify Users" />
    </form> 
    <form action="modify-courses.php">
         <input type="submit" value="Modify Courses" />
    </form> 
    <form action="modify-teachers.php">
         <input type="submit" value="Modify Teachers" />
    </form> 
    <form action="print-report.php">
         <input type="submit" value="Print Report Cards" />
    </form> 
    <form action="print-transcripts.php">
         <input type="submit" value="Print Transcripts" />
    </form> 
    <form action="../login.php">
         <input type="submit" value="Logout" />
    </form> 
    <script src="../scripts/admin.js">
        
    </script>
    </div>
   
</body>
</html>
