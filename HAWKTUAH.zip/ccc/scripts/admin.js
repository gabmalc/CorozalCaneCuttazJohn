let modify_class = document.querySelector("#modify-class");
let modify_student = document.querySelector("#modify-student");
let modify_courses = document.querySelector("#modify-courses");
let modify_teacher = document.querySelector("#modify-teacher");
modify_class.addEventListener("click", () => {
  alert("Modify class");
});

modify_student.addEventListener("click", () => {
  alert("Modify student");
});

modify_courses.addEventListener("click", () => {
  alert("Modify Courses");
});

modify_teacher.addEventListener("click", () => {
  alert("Modify Teachers");
});
