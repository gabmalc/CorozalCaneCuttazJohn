function makeEditable(element, teacherId, field) {
    const currentValue = element.textContent.trim();
    const input = document.createElement('input');
    input.type = field === 'email' ? 'email' : 'text';
    input.value = currentValue;
    input.className = 'editing';
    
    element.innerHTML = '';
    element.appendChild(input);
    input.focus();

    function saveChange(newValue) {
        if (newValue.trim() === '') {
            alert('Field cannot be empty');
            return false;
        }

        const formData = new FormData();
        formData.append('update_teacher', '1');
        formData.append('teacher_id', teacherId);
        formData.append('field', field);
        formData.append('value', newValue);

        fetch(window.location.href, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                element.innerHTML = newValue;
                element.dataset.original = newValue;
                // If name is updated, reload to update course assignments
                if (field === 'name') {
                    location.reload();
                }
                // Add visual feedback
                element.style.backgroundColor = '#e8f5e9';
                setTimeout(() => {
                    element.style.backgroundColor = '';
                }, 1000);
            } else {
                alert(data.message || 'Update failed');
                element.innerHTML = element.dataset.original;
            }
        })
        .catch(error => {
            console.error('Error:', error);
            element.innerHTML = element.dataset.original;
            alert('Failed to update. Please try again.');
        });
    }

    input.onblur = function() {
        if (input.value !== currentValue) {
            saveChange(this.value);
        } else {
            element.innerHTML = element.dataset.original;
        }
    };

    input.onkeydown = function(e) {
        if (e.key === 'Enter') {
            if (input.value !== currentValue) {
                saveChange(this.value);
            } else {
                element.innerHTML = element.dataset.original;
            }
        } else if (e.key === 'Escape') {
            element.innerHTML = element.dataset.original;
        }
    };
}

function updateCourses(teacherId) {
    const checkboxes = document.querySelectorAll(`.course-checkbox[data-teacher-id="${teacherId}"]`);
    const selectedCourses = Array.from(checkboxes)
        .filter(cb => cb.checked)
        .map(cb => cb.value);
    
    const formData = new FormData();
    formData.append('update_courses', '1');
    formData.append('teacher_id', teacherId);
    formData.append('courses', JSON.stringify(selectedCourses));
    
    // Show loading state
    const courseList = document.querySelector(`#teacher-${teacherId} .course-list`);
    courseList.style.opacity = '0.5';
    
    fetch(window.location.href, {
        method: 'POST',
        body: formData
    })
    .then(response => response.json())
    .then(data => {
        courseList.style.opacity = '1';
        if (data.status === 'success') {
            // Add visual feedback
            courseList.style.backgroundColor = '#e8f5e9';
            setTimeout(() => {
                courseList.style.backgroundColor = '';
            }, 1000);
        } else {
            alert('Error updating course assignments');
            location.reload();
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Error updating course assignments');
        location.reload();
    });
}

function deleteTeacher(teacherId) {
    if (confirm('Are you sure you want to delete this teacher? This will also remove all their course assignments.')) {
        const formData = new FormData();
        formData.append('delete_teacher', '1');
        formData.append('teacher_id', teacherId);

        const teacherRow = document.getElementById(`teacher-${teacherId}`);
        teacherRow.style.opacity = '0.5';

        fetch(window.location.href, {
            method: 'POST',
            body: formData
        })
        .then(response => response.json())
        .then(data => {
            if (data.status === 'success') {
                teacherRow.remove();
            } else {
                alert('Failed to delete teacher');
                teacherRow.style.opacity = '1';
            }
        })
        .catch(error => {
            console.error('Error:', error);
            alert('Failed to delete teacher');
            teacherRow.style.opacity = '1';
        });
    }
}

// Handle the add teacher form
document.getElementById('addTeacherForm').addEventListener('submit', function(e) {
    e.preventDefault();
    
    // Basic validation
    const name = this.querySelector('input[name="name"]').value.trim();
    const email = this.querySelector('input[name="email"]').value.trim();
    const username = this.querySelector('input[name="username"]').value.trim();
    
    if (!name || !email || !username) {
        alert('Please fill in all required fields');
        return;
    }
    
    // Email validation
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    if (!emailRegex.test(email)) {
        alert('Please enter a valid email address');
        return;
    }
    
    // Get selected courses
    const selectedCourses = Array.from(this.querySelectorAll('input[name="courses[]"]:checked'))
        .map(cb => cb.value);
    
    const formData = new FormData(this);
    formData.append('add_teacher', '1');
    
    // Show loading state
    const submitButton = this.querySelector('button[type="submit"]');
    const originalText = submitButton.textContent;
    submitButton.textContent = 'Adding...';
    submitButton.disabled = true;
    
    fetch(window.location.href, {
        method: 'POST',
        body: formData
    })
    .then(response => {
        if (response.ok) {
            location.reload();
        } else {
            throw new Error('Network response was not ok');
        }
    })
    .catch(error => {
        console.error('Error:', error);
        alert('Failed to add teacher. Please try again.');
        submitButton.textContent = originalText;
        submitButton.disabled = false;
    });
});

// Add visual feedback for checkboxes
document.querySelectorAll('.course-checkbox').forEach(checkbox => {
    checkbox.addEventListener('change', function() {
        this.parentElement.style.backgroundColor = '#e8f5e9';
        setTimeout(() => {
            this.parentElement.style.backgroundColor = '';
        }, 1000);
    });
});

// Initialize tooltips for better UX
document.querySelectorAll('.editable').forEach(element => {
    element.title = 'Click to edit';
});

// Add loading indicator to the page
window.addEventListener('load', function() {
    const style = document.createElement('style');
    style.textContent = `
        .loading {
            opacity: 0.5;
            pointer-events: none;
        }
        .success-flash {
            animation: flashSuccess 1s;
        }
        @keyframes flashSuccess {
            0% { background-color: #e8f5e9; }
            100% { background-color: transparent; }
        }
    `;
    document.head.appendChild(style);
});
</script>